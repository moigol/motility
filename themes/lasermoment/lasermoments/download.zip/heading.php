<section class="page-header">
    <div class="wrap">
        <h1 class="heading"><?php the_title(); ?></h1>
        
        <span class="h-next"><?php bcn_display(); ?></span>
    </div>
    <div class="clear"></div>
    
</section>